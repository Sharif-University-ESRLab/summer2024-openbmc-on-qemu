OpenBMC
================

meta-phosphor is the OpenBMC layer. This layer should be included for all
OpenBMC systems. The OpenBMC layer contains content which is shared between all
OpenBMC systems.
